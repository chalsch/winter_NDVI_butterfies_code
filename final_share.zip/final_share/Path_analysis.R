###################################################################
###################################################################

#Code for "Thirty-six years of butterfly monitoring, snow cover, 
#and plant productivity reveal negative impacts of warmer winters 
#and increased productivity on montane species" pt. 2

#Author: Chris Halsch
#Date: Nov 6, 2023

#Below you will find the code relevant for running the the path analysis
#and creating figures 3 and 4 from the main text. The data formatting, factor
#analysis, and the Donner model are found in other scripts. 

#IMPORTANT NOTE FOR RUNNING THIS CODE: 
#The model presented below needs to be run twice. Once for all species,
#where the impact of Fall is removed (because early flying species do not 
#experience the Fall). Then run a second time where the impacts of Fall are added,
#after early flying species are removed. There are instructions in the script below
#about when and where to comment out certain lines. If not explicitly stated
#then the code block should be run. Blocks are separated by lines of #.

#Line 32: Bayesian path analysis
#Line 251: Beginning to summarize the model
#Line 374: Summarizing total effects
#Line 649: Recreating figure 3 (model summary) 
#Line 828: Relationship with the drought (fig 4)

###################################################################
###################################################################

######################################################
##########      Bayesian path analysis      ##########
######################################################

setwd("~/Documents/MANUSCRIPTS/remote_meadows/data_share/final_share/")

library(data.table)
library(ggbeeswarm)
library(ggforce)
library(ggpubr)
library(igraph)
library(stringr)
library(tidyverse)
library(viridis)
library(wesanderson)

#Load Butterfly data with trends
dat <- read.csv("SEM_data_share_trended.csv")

#Just some housekeeping
dat <- dat %>% 
  filter(Year >= 1985) %>%
  mutate(species = as.numeric(factor(genus_species)),
         site = as.numeric(factor(site_name)),
         species_site_name = paste(genus_species, site_name, sep = "_"),
         Year = scale(Year)[,1]) %>% 
  rename(lagButt = lag_fDP)

#identifies species that only fly early in the season
early_species <- dat %>%
  group_by(genus_species, site_name) %>% 
  summarise(mdlf = mean(mdlf, na.rm = T)) %>% 
  filter(mdlf <  182) %>% 
  mutate(species_site_name = paste(genus_species, site_name, sep = "_"))

#Only select columns needed for analyis
model_dat <- dat %>% 
  select(site_name, genus_species, species_site_name, DP, visits, Year, NDVI, MR1, MR2, MR3, MR4, lagButt, lagNDVI, lagMR1, lagMR2, lagMR3, lagMR4) 

#scales predictor variables within each site
sites <- unique(model_dat$site_name)
outlist <- list()
for (i in 1:length(sites)) {
  temp <- model_dat %>% filter(site_name == sites[i])
  temp1 <- data.frame(apply(temp[,6:ncol(temp)], 2, scale))
  temp1$site_name <- temp$site_name
  temp1$genus_species <- temp$genus_species
  temp1$DP <- temp$DP
  temp1$visits <- temp$visits
  temp1$species_site_name <- temp$species_site_name
  outlist[[i]] <- temp1
}
z_data <- data.table::rbindlist(outlist) 

################################################################
#### RUN THIS BLOCK FOR ALL SPECIES MODEL ####

#Creates matrix of predictors for the butterfly model. Use this line if running model on all species,
#which excludes the Fall variable (MR)
Butt_preds <- z_data %>% 
  select(Year, NDVI, MR1, MR2, MR3, lagButt, lagNDVI, lagMR1, lagMR2, lagMR3, lagMR4)

#Creates matrix of predictors of NDVI
NDVI_preds <- z_data %>% 
  select(Year, MR1, MR2, MR3, MR4, lagMR1, lagMR2, lagMR3, lagMR4)

################################################################

################################################################
#### RUN THIS BLOCK FOR EXCLUDING EARLY SPECIES ####

lat <- subset(z_data, !(species_site_name %in% early_species$species_site_name))
z_data <- lat

#Creates matrix of predictors for the butterfly model. Use this line if running model that excludes 
#early species, which includes the Fall variable (MR4)
Butt_preds <- z_data %>% 
  select(Year, NDVI, MR1, MR2, MR3, MR4, lagButt, lagNDVI, lagMR1, lagMR2, lagMR3, lagMR4)

#Creates matrix of predictors of NDVI
NDVI_preds <- z_data %>% 
  select(Year, MR1, MR2, MR3, MR4, lagMR1, lagMR2, lagMR3, lagMR4)

################################################################

#Looks at correlations among variables
#ggcorrplot::ggcorrplot(cor(Butt_preds), type = "lower", lab = T)
#ggsave("corr_vars.png", width = 10, height = 8)

#data for JAGS model
mod_data <- list(
  Butt = z_data$DP,
  Visits = z_data$visits,
  NDVI = z_data$NDVI,
  X1 = as.matrix(Butt_preds),
  X2 = as.matrix(NDVI_preds),
  species_index = as.numeric(factor(z_data$genus_species)),
  site_index = as.numeric(factor(z_data$site_name)),
  Ncovars1 = ncol(Butt_preds),
  Ncovars2 = ncol(NDVI_preds),
  site_list = as.numeric(factor(str_split(unique(z_data$species_site_name), pattern = "_", simplify = T)[,2])),
  species_list = as.numeric(factor(str_split(unique(z_data$species_site_name), pattern = "_", simplify = T)[,1])),
  Nspecies_site_name = length(unique(z_data$species_site_name)),
  Nsite_name = length(unique(z_data$site_name)),
  N = length(z_data$Year))

#Bayesian model
sem_model <- "model {
          
          for (i in 1:N) { 
          
          #Lowest level. Here you can see the two multiple regressions, which creates the SEM framework. I use a martrix of predictotrs (X1)
          #where wach beta coefficient is nested within [, site_index[i], species_index[i]], which results in a different estimate for each species and site combination.
              
              #Likelihood for Butterfly model
              Butt[i] ~ dbinom(p[i], Visits[i])
              logit(p[i]) <- A1[site_index[i], species_index[i]] + B1[, site_index[i], species_index[i]] %*% X1[i,]
              
              #Likelihood for NDVI model
              NDVI[i] ~ dnorm(mu2[i], sigma2)
              mu2[i]  <- A2[site_index[i], species_index[i]] + B2[, site_index[i], species_index[i]] %*% X2[i,]

              LogLik1[i] <- logdensity.bin(Butt[i], p[i] , Visits[i]) #only use if you want model diagnostics. It adds much more computation.
              ButtP[i] ~ dbinom(p[i], Visits[i]) #only use if you want model diagnostics. It adds much more computation.
              
              LogLik2[i] <- log(dnorm(NDVI[i], mu2[i], sigma2)) #only use if you want model diagnostics. It adds much more computation.
              NDVIP[i] ~ dnorm(mu2[i], sigma2) #only use if you want model diagnostics. It adds much more computation.
              
          }
          
          #Sets priors for each population in butterfly model (drawn from site level distribution)
          for (j in 1:Ncovars1) {
            for (k in 1:Nspecies_site_name) {
            
              B1[j, site_list[k], species_list[k]] ~ dnorm(mbmu1[j,site_list[k]], mbsig1[j,site_list[k]])
            
            }
          }
          
          #Sets priors for each site in butterfly model (drawn from across site level distribution)
          for (j in 1:Ncovars1) {
            for (k in 1:Nsite_name) {
              mbmu1[j,k] ~ dnorm(hbmu1[j], hbsig1[j])
              mbsig1[j,k] ~ dgamma(2, 0.1)
              }
            }
          
          #Vaguely informative prior on across site distribution
          for (j in 1:Ncovars1) {
            hbmu1[j] ~ dnorm(0, 0.1)
            hbsig1[j] ~ dgamma(2, 0.1)
          }
          
          #Sets priors for each population in NDVI model (drawn from site level distribution)
          for (j in 1:Ncovars2) {
            for (k in 1:Nspecies_site_name) {
            
              B2[j, site_list[k], species_list[k]] ~ dnorm(mbmu2[j, site_list[k]], mbsig2[j, site_list[k]])
            }
          }
            
          #Sets priors for each site in NDVI model (drawn from across site level distribution)
           for (j in 1:Ncovars2) {
            for (k in 1:Nsite_name) {
              
            mbmu2[j,k] ~ dnorm(hbmu2[j], hbsig2[j])
            mbsig2[j,k] ~ dgamma(2, 0.1)
            }
           }
          
          #Vaguely informative prior on across site distribution
          for (j in 1:Ncovars2) {
            hbmu2[j] ~ dnorm(0, 0.1)
            hbsig2[j] ~ dgamma(2, 0.1)
          }
          
          #Priors for intercept of both models
          for (k in 1:Nspecies_site_name) {
            A1[site_list[k], species_list[k]] ~ dnorm(mamu1[site_list[k]], masig1[site_list[k]])
            A2[site_list[k], species_list[k]] ~ dnorm(mamu2[site_list[k]], masig2[site_list[k]])
          }
          
          for (k in 1:Nsite_name) {

            mamu1[k] ~ dnorm(hamu1, hasig1)
            mamu2[k] ~ dnorm(hamu2, hasig2)

            masig1[k] ~ dgamma(2, 0.1)
            masig2[k] ~ dgamma(2, 0.1)
          }
          
        hamu1 ~ dnorm(0, 0.1)
        hasig1 ~ dgamma(2, 0.1)
        hamu2 ~ dnorm(0, 0.1)
        hasig2 ~ dgamma(2, 0.1)
        
        sigma2 ~ dgamma(2, 0.1)

}	
"

writeLines(sem_model, con="sem_model.txt")

#Set parameters to save
params <- c("B1", "B2", "hbmu1", "hbmu2", "mbmu1", "mbmu2", "p")
#params <- c("B1", "B2", "hbmu1", "hbmu2", "mbmu1", "mbmu2", "p", "LogLik1", "ButtP", "LogLik2", "NDVIP") #use if you want model diagnostics

#Run the jags model
mod <- jagsUI::jags(data = mod_data,
                    n.adapt = 500,
                    n.burnin = 500,
                    n.iter = 5000,
                    n.chains = 4,
                    modules = "glm",
                    parallel = T,
                    model.file = "sem_model.txt",
                    parameters.to.save = params,
                    verbose = TRUE)

################################################################
##########      Beginning to summarize the model      ##########
################################################################

summ <- data.frame(mod$summary)

################################################################
#This first block summarizes the coefficients and prepares for 
#menard transformation

dat_to_merge <- z_data
dat_to_merge$other <- as.character(1:nrow(z_data))
#dat_to_merge$site_name <- z_data$site_name
#dat_to_merge$genus_species <- z_data$genus_species

#This code summarizes the population level coefficients
summp_B <- summ %>% 
  mutate(get_it = rownames(summ), get_it = substr(get_it, start = 1, stop = (nchar(get_it)-1))) %>% 
  separate(get_it, into = c("resp_index", "other"), sep = "\\[") %>% 
  filter(resp_index == "p") %>% 
  left_join(dat_to_merge, by = "other") %>% 
  select(site_name, genus_species, mean, DP, visits, colnames(Butt_preds)) %>% 
  mutate(logit_mean = gtools::logit(mean)) %>% 
  group_by(site_name, genus_species) %>% 
  summarise(sd_logit = sd(logit_mean),
            cor_logit = cor(logit_mean, DP/visits)) %>% 
  mutate(level = "B")

#This code summarizes the site level coefficients
summp_mbmu <- summ %>% 
  mutate(get_it = rownames(summ), get_it = substr(get_it, start = 1, stop = (nchar(get_it)-1))) %>% 
  separate(get_it, into = c("resp_index", "other"), sep = "\\[") %>% 
  filter(resp_index == "p") %>% 
  left_join(dat_to_merge, by = "other") %>% 
  select(site_name, genus_species, mean, DP, visits, colnames(Butt_preds)) %>% 
  mutate(logit_mean = gtools::logit(mean)) %>% 
  group_by(site_name) %>% 
  summarise(sd_logit = sd(logit_mean),
            cor_logit = cor(logit_mean, DP/visits)) %>% 
  mutate(level = "mbmu", genus_species = "overall") %>%
  select(site_name, genus_species, sd_logit, cor_logit, level)

#This code summarizes the across all sites level coefficients
summp_hbmu <- summ %>% 
  mutate(get_it = rownames(summ), get_it = substr(get_it, start = 1, stop = (nchar(get_it)-1))) %>% 
  separate(get_it, into = c("resp_index", "other"), sep = "\\[") %>% 
  filter(resp_index == "p") %>% 
  left_join(dat_to_merge, by = "other") %>% 
  select(site_name, genus_species, mean, DP, visits, colnames(Butt_preds)) %>% 
  mutate(logit_mean = gtools::logit(mean)) %>% 
  group_by(.) %>% 
  summarise(sd_logit = sd(logit_mean),
            cor_logit = cor(logit_mean, DP/visits)) %>% 
  mutate(level = "hbmu", genus_species = "overall", site_name = "overall") %>% 
  select(site_name, genus_species, sd_logit, cor_logit, level)

#merge all coefficients
conversions <- rbind(summp_B, summp_hbmu, summp_mbmu)

################################################################

################################################################
#This block joins model outputs with species names, site names,
#predictor names, and response variable names

species_key <- data.frame(species_index = as.character(1:length(levels(factor(z_data$genus_species)))),
                          genus_species = levels(factor(z_data$genus_species)))

site_key <- data.frame(site_index = as.character(as.numeric(factor(unique(z_data$site_name)))),
                       site_name = levels(factor(z_data$site_name)))

predictor_key1 <- data.frame(pred_index = as.character(1:ncol(Butt_preds)),
                             predictors = colnames(Butt_preds),
                             resp_index = rep("1", ncol(Butt_preds)),
                             response = rep("Butt", ncol(Butt_preds)))

predictor_key2 <- data.frame(pred_index = as.character(1:ncol(NDVI_preds)),
                             predictors = colnames(NDVI_preds),
                             resp_index = rep("2", ncol(NDVI_preds)),
                             response = rep("NDVI", ncol(NDVI_preds)))


predictor_key <- rbind(predictor_key1, predictor_key2)


#Summarizes all of the model outputs (including calculating menard transformation)
summ1 <- summ %>% 
  mutate(get_it = rownames(summ), get_it = substr(get_it, start = 1, stop = (nchar(get_it)-1))) %>% 
  separate(get_it, into = c("resp_index", "other"), sep = "\\[") %>%
  filter(resp_index != "p") %>% 
  filter(resp_index != "devianc") %>% 
  mutate(level = substr(resp_index, start = 1, stop = (nchar(resp_index)-1)),
         resp_index = substr(resp_index, start = (nchar(resp_index)), stop = (nchar(resp_index)))) %>% 
  separate(other, into = c("pred_index", "site_index", "species_index"), sep = "\\,") %>% 
  #mutate(other = substr(other, start = 1, stop = (nchar(other)-1))) %>% 
  #separate(other, into = c("pred_index", "spec_index"), sep = "\\,") %>% 
  left_join(site_key) %>% 
  left_join(species_key) %>% 
  left_join(predictor_key) %>% 
  mutate(site_name = ifelse(is.na(site_name) == T, "overall", site_name),
         genus_species = ifelse(is.na(genus_species) == T, "overall", genus_species),
         species_site_name = paste(genus_species, site_name, sep = "_")) %>% 
  select(-resp_index, -pred_index, -species_index, -site_index) %>% 
  left_join(conversions, by = c("site_name", "genus_species", "level")) %>% 
  mutate(men_mean = mean* cor_logit / sd_logit,
         men_X2.5. = X2.5.* cor_logit / sd_logit,
         men_X97.5. = X97.5.* cor_logit / sd_logit)

#AFTER SUMMARIZING THE MODEL OUTPUTS SAVE IT USING THE FOLLOWING LINES (summ_ear for early model
#and summ_lat for the late model). THEN MOVE ON TO THE NEXT BLOCK TO CALCULATE TOTAL EFFECTS.  
#ONCE BOTH MODELS ARE RUN COMBINE USING "summ_all".

#USE THIS LINE IF YOU RAN THE EARLY MODEL
summ_ear <- subset(summ1, (species_site_name %in% early_species$species_site_name))

#USE THIS LINE IF YOU RAN THE LATE MODEL
summ_lat <- subset(summ1, !(species_site_name %in% early_species$species_site_name))

#Merges both models into one output (used for the rest of the script)
summ_all <- rbind(summ_ear, summ_lat)

################################################################

################################################################
##############      Summarizing total effects     ##############
################################################################

################################################################
#This block samples from the posterior distribution for each coefficient
#in the model. 

set.seed(666)
sams <- sample(1:18000, 1000)

outlist1 <- list()
outlist2 <- list()
for (i in 1:mod_data$Ncovars1) {
  for (j in 1:mod_data$Nspecies_site_name) {
    temp <- mod$sims.list$B1[sams, i, mod_data$site_list[j], mod_data$species_list[j]]
    temp1 <- data.frame(sam = temp,
                        sam_num = sams)
    temp1$resp_index <- 1
    temp1$pred_index <- i
    temp1$site_index <- mod_data$site_list[j]
    temp1$species_index <- mod_data$species_list[j]
    
    outlist1[[j]] <- temp1
  }
  outlist2[[i]] <- data.table::rbindlist(outlist1)
  print(i)
}

outlist3 <- list()
outlist4 <- list()
for (i in 1:mod_data$Ncovars2) {
  for (j in 1:mod_data$Nspecies_site_name) {
    temp <- mod$sims.list$B2[sams, i, mod_data$site_list[j], mod_data$species_list[j]]
    temp1 <- data.frame(sam = temp,
                        sam_num = sams)
    temp1$resp_index <- 2
    temp1$pred_index <- i
    temp1$site_index <- mod_data$site_list[j]
    temp1$species_index <- mod_data$species_list[j]
    
    outlist3[[j]] <- temp1
  }
  outlist4[[i]] <- data.table::rbindlist(outlist3)
  print(i)
}
################################################################

#AFTER SAMPLING FROM POSTERIORS SAVE IT USING THE FOLLOWING BLOCKS (ear for early model
#and lat for the late model). ONCE THIS IS DONE EITHER RUN THE OTHER MODEL OR MOVE ON.
#ONCE BOTH MODELS ARE RUN COMBINE USING "all_all".

################################################################
##### Use this block if you ran the early model #####
butt_ear <- data.table::rbindlist(outlist2)
butt_ear <- butt_ear %>% 
  mutate(resp_index = as.character(resp_index),
         pred_index = as.character(pred_index),
         site_index = as.character(site_index),
         species_index = as.character(species_index)) %>% 
  left_join(site_key) %>% 
  left_join(species_key) %>% 
  left_join(predictor_key) %>% 
  left_join(conversions, by = c("site_name", "genus_species")) %>% 
  filter(level == "B") %>% 
  mutate(sam = sam * cor_logit / sd_logit) %>% 
  select(sam, sam_num, resp_index, pred_index, site_index, species_index,
         site_name, genus_species, predictors, response, sd_logit, cor_logit, level)

NDVI_ear <- data.table::rbindlist(outlist4)
NDVI_ear <- NDVI_ear %>%
  mutate(resp_index = as.character(resp_index),
         pred_index = as.character(pred_index),
         site_index = as.character(site_index),
         species_index = as.character(species_index)) %>% 
  left_join(site_key) %>% 
  left_join(species_key) %>% 
  left_join(predictor_key) %>% 
  left_join(conversions, by = c("site_name", "genus_species"))

all_ear1 <- rbind(butt_ear, NDVI_ear)
all_ear1 <- all_ear1 %>% 
  mutate(species_site_name = paste(genus_species, site_name, sep = "_"))
all_ear1 <- subset(all_ear1, (species_site_name %in% early_species$species_site_name))

################################################################

################################################################
##### Use this block if you ran the late model #####
butt_lat <- data.table::rbindlist(outlist2)
butt_lat <- butt_lat %>% 
  mutate(resp_index = as.character(resp_index),
         pred_index = as.character(pred_index),
         site_index = as.character(site_index),
         species_index = as.character(species_index)) %>% 
  left_join(site_key) %>% 
  left_join(species_key) %>% 
  left_join(predictor_key) %>% 
  left_join(conversions, by = c("site_name", "genus_species")) %>% 
  filter(level == "B") %>% 
  mutate(sam = sam * cor_logit / sd_logit) %>% 
  select(sam, sam_num, resp_index, pred_index, site_index, species_index,
         site_name, genus_species, predictors, response, sd_logit, cor_logit, level)

NDVI_lat <- data.table::rbindlist(outlist4)
NDVI_lat <- NDVI_lat %>%
  mutate(resp_index = as.character(resp_index),
         pred_index = as.character(pred_index),
         site_index = as.character(site_index),
         species_index = as.character(species_index)) %>% 
  left_join(site_key) %>% 
  left_join(species_key) %>% 
  left_join(predictor_key) %>% 
  left_join(conversions, by = c("site_name", "genus_species"))

all_lat1 <- rbind(butt_lat, NDVI_lat)
all_lat1 <- all_lat1 %>% 
  mutate(species_site_name = paste(genus_species, site_name, sep = "_"))
all_lat1 <- subset(all_lat1, !(species_site_name %in% early_species$species_site_name))

################################################################

#This line merges the outputs of the two models
all_all <- rbind(all_ear1, all_lat1)

#ONCE YOU HAVE RUN THIS LINE (having run both modeels). YOU CAN MOVE ON.

################################################################
#This massive block calculates the total effects of each coefficient by
#generating networks for each sample of each coefficient and then adding 
#across pathways. I also calculate the contribution each weather variable
#makes to indirect effects

config_lags <- all_all %>% 
  filter(predictors == "MR1" | predictors == "MR2" | predictors == "MR3" | predictors == "MR4") %>% 
  filter(response == "NDVI") %>% 
  mutate(predictors = paste0("lag", predictors),
         response = paste0("lag", response))
summ2 <- rbind(all_all, config_lags) 

paths <- distinct(data.frame(predictors = summ2$predictor, response = summ2$response))
paths <- as.matrix(paths)

species_site <- data.frame(speciessite = unique(paste(summ2$genus_species, summ2$site_name, sep = "_")))
species_site <- separate(species_site, speciessite, into = c("genus_species", "site_name"), sep = "_")

g <- graph_from_edgelist(paths)
clim <- c("MR1", "MR2", "MR3", "MR4", "lagMR1", "lagMR2", "lagMR3", "lagMR4", "Year")

out <- data.frame(genus_species = species_site$genus_species,
                  site_name = species_site$site_name)
outlist <- list()
for (i in 1:length(clim)) {
  
  temp_paths <- all_simple_paths(g, from = clim[i], to = "Butt")
  
  for (j in 1:length(temp_paths)) {
    
    temp_path <- temp_paths[j]
    tst <- data.frame(genus_species = NA, site_name = NA, predictors = NA, response = NA)
    
    for (k in 2:length(temp_path[[1]])) {
      
      tst1 <- data.frame(genus_species = species_site$genus_species,
                         site_name = species_site$site_name,
                         predictors = rep(names(temp_path[[1]])[k-1], nrow(species_site)), 
                         response = rep(names(temp_path[[1]])[k], nrow(species_site)))
      
      tst <- rbind(tst, tst1)
    }
    
    tst <- tst[-1,]
    
    temp <- left_join(tst, summ2, c("genus_species", "site_name", "predictors", "response"))
    order <- unique(paste(temp$predictors, temp$response, sep = "->"))
    
    temp <- temp %>%
      mutate(path = paste(predictors, response, sep = "->")) %>% 
      select(genus_species, site_name, path, sam, sam_num) %>% 
      spread(key = path, value = sam) 

    if (ncol(temp) > 4) {
      temp$path <- apply(temp[,4:ncol(temp)], MARGIN = 1, FUN = prod)
      colnames(temp)[ncol(temp)] <- paste(names(temp_path[[1]]), collapse = "->")
    }
    
    if (j == 1) {
      out_temp <- temp[,c(1,2,3,ncol(temp))] }
    
    if (j != 1) {
      out_temp1 <- temp[,c(1,2,3,ncol(temp))]
      out_temp <- left_join(out_temp, out_temp1, by = c("genus_species", "site_name", "sam_num"))
      
    }
    
  }
  out_temp1 <- out_temp %>% 
    gather(4:ncol(.), key = "path", value = sam)
  
  out_indirect <- out_temp1 %>% 
    filter(grepl('NDVI', path)) %>% 
    group_by(genus_species, site_name, sam_num) %>% 
    summarise(tot_indir = sum(sam))
  
  out_direct <- out_temp1 %>% 
    filter(!grepl('NDVI', path)) %>% 
    group_by(genus_species, site_name, sam_num) %>% 
    summarise(tot_dir = sum(sam)) %>% 
    left_join(out_indirect)
  
  out_direct$total <- out_direct$tot_dir+out_direct$tot_indir
  #out_direct$prop <- log(abs(out_direct$tot_dir)/abs(out_direct$tot_indir))
  #out_temp <- out_temp %>% 
  #select(genus_species, site_name, sam_num, sum)
  #group_by(genus_species, site_name) %>% 
  #summarise(mn = mean(sum),
  #         f = length(sum[sum > 0])/1000) %>% 
  #mutate(f = ifelse(f < 0.5, 1-f, f))
  out_direct$clim <- clim[i]
  outlist[[i]] <- out_direct
  
}

out <- data.table::rbindlist(outlist)
################################################################

################################################################
#This block summarizes the total effects at the population level
out1 <- out %>% 
  mutate(clim = ifelse(substr(clim, 1, 3) == "lag", substr(clim, 4, 7), clim)) %>% 
  group_by(genus_species, site_name, sam_num, clim) %>%
  summarise(comb_tot = sum(total, na.rm = T),
            comb_dir = sum(tot_dir, na.rm = T),
            comb_indir = sum(tot_indir, na.rm = T)) %>% 
  mutate(comb_prop = log(abs(comb_dir)/abs(comb_indir))) %>% 
  group_by(genus_species, site_name, clim) %>%
  summarise(mn_tot = mean(comb_tot, na.rm = T),
            f_tot = length(comb_tot[comb_tot > 0])/1000,
            mn_dir = mean(comb_dir, na.rm = T),
            f_dir = length(comb_dir[comb_dir > 0])/1000,
            mn_indir = mean(comb_indir, na.rm = T),
            f_indir = length(comb_indir[comb_indir > 0])/1000,
            mn_prop = mean(comb_prop, na.rm = T),
            f_prop = length(comb_prop[comb_prop > 0])/1000) %>% 
  mutate(f_tot = ifelse(f_tot < 0.5, 1-f_tot, f_tot),
         f_dir = ifelse(f_dir < 0.5, 1-f_dir, f_dir),
         f_indir = ifelse(f_indir < 0.5, 1-f_indir, f_indir),
         f_prop = ifelse(f_prop < 0.5, 1-f_prop, f_prop)) %>% 
  mutate(clim = factor(clim, levels = c("Year", "MR4", "MR2", "MR3", "MR1"))) %>% 
  filter(mn_tot != 0)

################################################################

################################################################
#This block summarizes the total effects by site
out1.5 <- out %>% 
  mutate(clim = ifelse(substr(clim, 1, 3) == "lag", substr(clim, 4, 7), clim)) %>% 
  group_by(genus_species, site_name, sam_num, clim) %>%
  summarise(comb_sum = sum(total),
            comb_sum_indir = sum(tot_indir)) %>% 
  group_by(site_name, clim) %>%
  #group_by(clim) %>%
  summarise(mn = mean(comb_sum, na.rm = T),
            lci = quantile(comb_sum, 0.1, na.rm = T),
            uci = quantile(comb_sum, 0.9,  na.rm = T),
            mn_indir = mean(comb_sum_indir, na.rm = T),
            lci_indir = quantile(comb_sum_indir, 0.1, na.rm = T),
            uci_indir = quantile(comb_sum_indir, 0.9,  na.rm = T)) %>% 
  mutate(clim = factor(clim, levels = c("Year", "MR4", "MR2", "MR3", "MR1")))
################################################################

##################################################################
##################################################################
##################################################################

##################################################################
#########      Recreating figure 4 (model summary)      ##########
##################################################################

################################################################
#Figure 4A. Total effects of each weather variable.
plot_tot1 <- ggplot(data = out1) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = "gray95") + 
  geom_vline(aes(xintercept = 0), color = "black", linetype = "dashed") +
  geom_hline(aes(yintercept = 1.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 2.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 3.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 4.5), color = "black", linetype = "dotted") +
  geom_quasirandom(data = subset(out1, f_tot < 0.8), aes(mn_tot, clim, fill = site_name), pch = 21, method = "quasirandom", alpha = 0.25, size = 2, dodge.width = -0.75) + #position = position_jitterdodge(dodge.width = 0.75, jitter.width = 0.15)) +
  geom_quasirandom(data = subset(out1, f_tot >= 0.8), aes(mn_tot, clim, fill = site_name), pch = 21,  method = "quasirandom", alpha = 0.75, size = 2,  dodge.width = -0.75) + #position = position_jitterdodge(dodge.width = 0.75, jitter.width = 0.15)) +
  geom_errorbarh(data = out1.5, aes(xmin = lci, xmax = uci, y = clim, group = site_name), color = "black", size = 1.5, height = 0, position = position_dodge(width = -0.75)) +
  geom_errorbarh(data = out1.5, aes(xmin = lci, xmax = uci, y = clim, color = site_name), size = 0.75, height = 0, position = position_dodge(width = -0.75), show.legend = F) +
  geom_point(data = out1.5, aes(mn, clim, fill = site_name), color = "black", size = 4, pch = 21, position = position_dodge(width = -0.75)) +
  #geom_errorbarh(data = out1.5, aes(xmin = lci, xmax = uci, y = clim), color = "black", size = 0.75, height = 0) +
  #geom_point(data = out1.5, aes(mn, clim), fill = "black", color = "black", size = 4, pch = 21) +
  scale_fill_manual(values = c("#FFDCA4", "#EFE737", "#CDEDD5")) +
  scale_color_manual(values = c("#FFDCA4", "#EFE737", "#CDEDD5")) +
  labs(x = "Total effect", fill = "Site", y = "Predictors") +
  scale_y_discrete(labels = c("Year", "Late growing\n season", "Early growing\nseason", "Late winter", "Early winter")) +
  theme_classic() +
  theme(legend.position = "none",
        legend.background = element_blank(),
        axis.title.y = element_blank(),
        axis.title.x = element_text(size = 20, face = "bold"),
        axis.text = element_text(size = 18),
        axis.line = element_blank(),
        legend.text = element_text(size = 18),
        legend.title = element_text(face = "bold", size = 20),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm"))
plot_tot1
################################################################

################################################################
#Figure 4B. Indirect effects of each weather variable.
plot_tot2 <- ggplot(data = out1) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = "gray95") + 
  geom_vline(aes(xintercept = 0), color = "black", linetype = "dashed") +
  geom_hline(aes(yintercept = 1.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 2.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 3.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 4.5), color = "black", linetype = "dotted") +
  geom_quasirandom(data = subset(out1, f_indir < 0.8), aes(mn_indir, clim, fill = site_name), pch = 21, method = "quasirandom", alpha = 0.25, size = 2, dodge.width = -0.75) + #position = position_jitterdodge(dodge.width = 0.75, jitter.width = 0.15)) +
  geom_quasirandom(data = subset(out1, f_indir >= 0.8), aes(mn_indir, clim, fill = site_name), pch = 21,  method = "quasirandom", alpha = 0.75, size = 2,  dodge.width = -0.75) + #position = position_jitterdodge(dodge.width = 0.75, jitter.width = 0.15)) +
  geom_errorbarh(data = out1.5, aes(xmin = lci_indir, xmax = uci_indir, y = clim, group = site_name), color = "black", size = 1.5, height = 0, position = position_dodge(width = -0.75)) +
  geom_errorbarh(data = out1.5, aes(xmin = lci_indir, xmax = uci_indir, y = clim, color = site_name), size = 0.75, height = 0, position = position_dodge(width = -0.75), show.legend = F) +
  geom_point(data = out1.5, aes(mn_indir, clim, fill = site_name), color = "black", size = 4, pch = 21, position = position_dodge(width = -0.75)) +
  #geom_errorbarh(data = out1.5, aes(xmin = lci_indir, xmax = uci_indir, y = clim), color = "black", size = 0.75, height = 0) +
  #geom_point(data = out1.5, aes(mn_indir, clim), fill = "black", color = "black", size = 4, pch = 21) +
  scale_fill_manual(values = c("#FFDCA4", "#EFE737", "#CDEDD5")) +
  scale_color_manual(values = c("#FFDCA4", "#EFE737", "#CDEDD5")) +
  labs(x = "Indirect effect", fill = "Site", y = "Predictors") +
  scale_y_discrete(labels = c("Year", "Late growing\n season", "Early growing\nseason", "Late winter", "Early winter")) +
  theme_classic() +
  theme(legend.position = "none",
        legend.background = element_blank(),
        axis.title.y = element_blank(),
        axis.title.x = element_text(size = 20, face = "bold"),
        axis.text = element_text(size = 18),
        axis.line = element_blank(),
        legend.text = element_text(size = 18),
        legend.title = element_text(face = "bold", size = 20),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm"))
plot_tot2
################################################################

################################################################
#Figure 4C. Same year path coefficients from path analysis
sep_mando1 <- summ_all  %>% 
  filter(substr(predictors, 1,3) != "lag") %>% 
  mutate(predictors = factor(predictors, levels = c("Year", "NDVI", "MR4", "MR2", "MR3", "MR1")))

sep_mando1.5 <- sep_mando1 %>% 
  filter(site_name != "overall") %>% 
  group_by(site_name, response, predictors) %>%
  #group_by(response, predictors) %>%
  summarise(mn = mean(mean, na.rm = T),
            lci = quantile(mean, 0.1, na.rm = T),
            uci = quantile(mean, 0.9,  na.rm = T)) %>% 
  mutate(predictors = factor(predictors, levels = c("Year", "NDVI", "MR4", "MR2", "MR3", "MR1")))

plot_sep1 <- ggplot() +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = "gray95") + 
  geom_vline(aes(xintercept = 0), color = "black", linetype = "dashed") +
  geom_hline(aes(yintercept = 1.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 2.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 3.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 4.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 5.5), color = "black", linetype = "dotted") +
  geom_quasirandom(data = subset(sep_mando1, response == "Butt" & level == "B" & f < 0.8), aes(mean, y=predictors, fill = site_name), pch = 21, method = "quasirandom", alpha = 0.25, size = 2, dodge.width = -0.75) + #position = position_jitterdodge(dodge.width = 0.75, jitter.width = 0.15)) +
  geom_quasirandom(data = subset(sep_mando1, response == "Butt" & level == "B" & f >= 0.8), aes(mean, y=predictors, fill = site_name), pch = 21,  method = "quasirandom", alpha = 0.75, size = 2,  dodge.width = -0.75) + #position = position_jitterdodge(dodge.width = 0.75, jitter.width = 0.15)) +
  geom_errorbarh(data = subset(sep_mando1.5, response == "Butt"), aes(xmin = lci, xmax = uci, y = predictors, group = site_name), color = "black", size = 1.5, height = 0, position = position_dodge(width = -0.75)) +
  geom_errorbarh(data = subset(sep_mando1.5, response == "Butt"), aes(xmin = lci, xmax = uci, y = predictors, color = site_name), size = 0.75, height = 0, position = position_dodge(width = -0.75)) +
  geom_point(data = subset(sep_mando1.5, response == "Butt"), aes(mn, predictors, fill = site_name), color = "black", size = 4, pch = 21, position = position_dodge(width = -0.75)) +
  #geom_errorbarh(data = subset(sep_mando1.5, response == "Butt"), aes(xmin = lci, xmax = uci, y = predictors), color = "black", size = 0.75, height = 0) +
  #geom_point(data = subset(sep_mando1.5, response == "Butt"), aes(mn, predictors), fill = "black", color = "black", size = 4, pch = 21) +
  scale_fill_manual(values = c("#FFDCA4", "#EFE737", "#CDEDD5")) +
  scale_color_manual(values = c("#FFDCA4", "#EFE737", "#CDEDD5")) +
  coord_cartesian(xlim = c(-0.5, 0.5)) +
  labs(x = "Same year effect", fill = "Site", y = "Predictors") +
  scale_y_discrete(labels = c("Year", "NDVI", "Late growing\nseason", "Early growing\nseason", "Late winter", "Early winter")) +
  theme_classic() +
  theme(legend.position = "none",
        legend.background = element_blank(),
        axis.title.y = element_blank(),
        axis.title.x = element_text(size = 20, face = "bold"),
        axis.text = element_text(size = 18),
        legend.text = element_text(size = 18),
        legend.title = element_text(face = "bold", size = 18),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        axis.line = element_blank(),
        plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm"))
plot_sep1
#ggsave("~/Documents/MANUSCRIPTS/remote_meadows/same_year.png", width = 8, height = 10)
################################################################

################################################################
#Figure 4D. Lag path coefficients from path analysis
sep_mando2 <- summ_all  %>% 
  filter(substr(predictors, 1,3) == "lag") %>% 
  mutate(predictors = factor(predictors, levels = c("lagButt", "lagNDVI", "lagMR4", "lagMR2", "lagMR3", "lagMR1")))

sep_mando2.5 <- sep_mando2 %>% 
  filter(site_name != "overall") %>% 
  group_by(site_name, response, predictors) %>%
  #group_by(response, predictors) %>%
  summarise(mn = mean(mean, na.rm = T),
            lci = quantile(mean, 0.1, na.rm = T),
            uci = quantile(mean, 0.9,  na.rm = T)) %>% 
  mutate(predictors = factor(predictors, levels = c("lagButt", "lagNDVI", "lagMR4", "lagMR2", "lagMR3", "lagMR1")))

plot_sep2 <- ggplot() +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = "gray95") + 
  geom_vline(aes(xintercept = 0), color = "black", linetype = "dashed") +
  geom_hline(aes(yintercept = 1.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 2.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 3.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 4.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 5.5), color = "black", linetype = "dotted") +
  geom_quasirandom(data = subset(sep_mando2, response == "Butt" & level == "B" & f < 0.8), aes(mean, predictors, fill = site_name), pch = 21, method = "quasirandom", alpha = 0.25, size = 2, dodge.width = -0.75) + #position = position_jitterdodge(dodge.width = 0.75, jitter.width = 0.15)) +
  geom_quasirandom(data = subset(sep_mando2, response == "Butt" & level == "B" & f >= 0.8), aes(mean, predictors, fill = site_name), pch = 21,  method = "quasirandom", alpha = 0.75, size = 2,  dodge.width = -0.75) + #position = position_jitterdodge(dodge.width = 0.75, jitter.width = 0.15)) +
  geom_errorbarh(data = subset(sep_mando2.5, response == "Butt"), aes(xmin = lci, xmax = uci, y = predictors, group = site_name), color = "black", size = 1.5, height = 0, position = position_dodge(width = -0.75)) +
  geom_errorbarh(data = subset(sep_mando2.5, response == "Butt"), aes(xmin = lci, xmax = uci, y = predictors, color = site_name), size = 0.75, height = 0, position = position_dodge(width = -0.75), show.legend = F) +
  geom_point(data = subset(sep_mando2.5, response == "Butt"), aes(mn, predictors, fill = site_name), color = "black", size = 4, pch = 21, position = position_dodge(width = -0.75)) +
  #geom_errorbarh(data = subset(sep_mando2.5, response == "Butt"), aes(xmin = lci, xmax = uci, y = predictors), color = "black", size = 0.75, height = 0) +
  #geom_point(data = subset(sep_mando2.5, response == "Butt"), aes(mn, predictors), fill = "black", color = "black", size = 4, pch = 21) +
  scale_fill_manual(values = c("#FFDCA4", "#EFE737", "#CDEDD5"), guide = guide_legend(override.aes = list(size = 2, alpha = 1, pch = 21))) +
  scale_color_manual(values = c("#FFDCA4", "#EFE737", "#CDEDD5")) +
  coord_cartesian(xlim = c(-0.5, 0.5)) +
  labs(x = "Prev. year effect", y = "Predictors", fill = "Site") +
  guides(fill = guide_legend(override.aes = list(size = 10))) + 
  scale_y_discrete(labels = c("Prev.\nbutterflies", "NDVI", "Late growing\nseason", "Early growing\nseason", "Late winter", "Early winter")) +
  theme_classic() +
  theme(legend.position = "bottom",
        legend.text = element_text(size = 18),
        axis.title.y = element_blank(),
        legend.title = element_text(face = "bold", size = 20),
        legend.spacing.x = unit(0.15, 'cm'),
        axis.title.x = element_text(size = 20, face = "bold"),
        axis.text = element_text(size = 18),
        axis.line = element_blank(),
        plot.margin = unit(c(0.5, 0.5,0.5,0.5), "cm"),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        legend.key.size = unit(2, 'cm'))
plot_sep2
#ggsave("~/Documents/MANUSCRIPTS/remote_meadows/lag_year.png", width = 8, height = 10)
################################################################

#Combine panels
ggpubr::ggarrange(plot_tot1, plot_tot2, plot_sep1, plot_sep2, nrow = 2, ncol = 2,  font.label = list(size = 25),
                  common.legend = T, legend = "bottom", labels = c("a", "b", "c", "d"))
#ggsave("~/Documents/MANUSCRIPTS/remote_meadows/model_fig.png", width = 12, height = 12)

####################################################################
#########      Relationship with the drought (fig 4)      ##########
####################################################################

#Read in life history data
life <- read.csv("life_withDFF.csv")
life <- life %>% 
  select(genus_species, site_name, resident, weedy, wintering, wingspan, mean_dff, mean_dlf, broods) %>% 
  mutate(species_site_name = paste(genus_species, site_name, sep = "_"))

#Read in drought response data
drought_res <- read.csv("drought_res.csv")

#Link total effects with drought
summ_rf <- out1 %>% 
  mutate(species_site_name = paste(genus_species, site_name, sep = "_")) %>% 
  select(species_site_name, clim, mn_tot) %>% 
  spread(key = clim, value = mn_tot) %>% 
  #left_join(trends, by = c("species_site_name", "genus_species", "site_name")) %>% 
  left_join(drought_res, by = c("species_site_name", "genus_species", "site_name")) %>% 
  left_join(life) %>% 
  filter(wintering != "no") %>% 
  mutate(wintering = factor(wintering, levels = c("egg", "larva", "pupa", "adult")))
  #na.omit()

#Set color palette
pal <- wes_palette("Zissou1", 100, type = "continuous")

################################################################
#Figure 5A. Correlation between winter and drought at Castle Peak r=0.24
p1<- ggplot(data = subset(summ_rf, site_name == "Castle Peak")) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = "gray95") + 
  geom_hline(aes(yintercept = 0), color = "black", linetype = "dashed") +
  geom_vline(aes(xintercept = 0), color = "black", linetype = "dashed") +
  #geom_point(aes(MR3, z_drought, fill = mean_dlf), pch = 21, size = 6, show.legend = F) + #panels a,c,e
  #scale_fill_gradientn(colors = pal) + #panels a,c,e
  geom_point(aes(MR3, z_drought, fill = wintering), pch = 21, size = 6, show.legend = F) + #panels b,d,f
  scale_fill_manual(values = wes_palette("IsleofDogs1")[c(2,3,5,1)]) + #panels b,d,f
  labs(x = "Warm winter effect", y = "Drought effect") +
  theme_classic() +
  theme(axis.title = element_text(size = 20, face = "bold"),
        axis.text = element_text(size = 18),
        axis.line = element_blank(),
        #legend.text = element_text(size = 13),
        #legend.title = element_text(face = "bold", size = 15),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm"))
p1
################################################################

################################################################
#Figure 5B. Correlation between winter and drought at Donner Pass r=0.28
p2<- ggplot(data = subset(summ_rf, site_name == "Donner Pass")) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = "gray95") + 
  geom_hline(aes(yintercept = 0), color = "black", linetype = "dashed") +
  geom_vline(aes(xintercept = 0), color = "black", linetype = "dashed") +
  #geom_point(aes(MR3, z_drought, fill = mean_dlf), pch = 21, size = 6, show.legend = F) + #panels a,c,e
  #scale_fill_gradientn(colors = pal) + #panels a,c,e
  geom_point(aes(MR3, z_drought, fill = wintering), pch = 21, size = 6, show.legend = F) + #panels b,d,f
  scale_fill_manual(values = wes_palette("IsleofDogs1")[c(2,3,5,1)]) + #panels b,d,f
  labs(x = "Warm winter effect", y = "Drought effect") +
  theme_classic() +
  theme(axis.title = element_text(size = 20, face = "bold"),
        axis.text = element_text(size = 18),
        axis.line = element_blank(),
        #legend.text = element_text(size = 13),
        #legend.title = element_text(face = "bold", size = 15),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm"))
p2
################################################################

################################################################
#Figure 5C. Correlation between winter and drought at Lang Crossing r=0.36
p3<- ggplot(data = subset(summ_rf, site_name == "Lang Crossing")) +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = "gray95") + 
  geom_hline(aes(yintercept = 0), color = "black", linetype = "dashed") +
  geom_vline(aes(xintercept = 0), color = "black", linetype = "dashed") +
  #geom_point(aes(MR3, z_drought, fill = mean_dlf), pch = 21, size = 6, show.legend = F) + #panels a,c,e
  #scale_fill_gradientn(colors = pal) + #panels a,c,e
  geom_point(aes(MR3, z_drought, fill = wintering), pch = 21, size = 6, show.legend = F) + #panels b,d,f
  scale_fill_manual(values = wes_palette("IsleofDogs1")[c(2,3,5,1)]) + #panels b,d,f
  labs(x = "Warm winter effect", y = "Drought effect") +
  theme_classic() +
  theme(axis.title = element_text(size = 20, face = "bold"),
        axis.text = element_text(size = 18),
        axis.line = element_blank(),
        #legend.text = element_text(size = 13),
        #legend.title = element_text(face = "bold", size = 15),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm"))
p3
################################################################

#Combine panels
ggpubr::ggarrange(p1, p2, p3, nrow = 3, ncol = 1,
                  labels = c("b", "d", "f"), font.label = list(size = 25))

#ggsave("~/Documents/MANUSCRIPTS/remote_meadows/MR3_fig1.2.png", width = 4, height = 12)





