Here you will find all the data files and the R script needed to rerun the analyses presented in the article "Thirty-six years of butterflies, snow cover, and plant productivity reveal negative impacts of warmer winters and increased primary productivity on montane species." The data are contained in the zip folder "final_share.zip" and contains the following files:

Climate.csv: the climate data extracted from the BCM. meadow_name refers to the monitoring site. Castle_big is not used. Year refers to the calendar year (NOT water year). Month is the month of the year. pck is the snow water equivalent (SWE). Ppt is precipitation. tmn is minimum temperature. tmx is maximum temperature.

SEM_data_share_trended.csv: the data needed for the path analysis. site_name is the monitoring site.  Year is the calendar year (weather HAS been adjusted for water year). genus_species identifies the genus and species of the observed butterfly. DP is the number of site visits in that year the butterfly was seen. Visits is the total number of site visits. Dff is the ordinal date the butterfly was first seen that year. Dlf is the ordinal date the butterfly was last seen. fDP is the DP/visits. lag_fDP is last years DP/visits. laglag_fDP is DP/visits from 2 years prior. Mdff is the average date of first flight from the time series. mdlf is the average date of last flight from across the time series. MR1 is the weather factor that describes snow accumulation. MR2 is the factor for early growing season. MR3 is the winter temperature factor. MR4 is the end of growing season factor. The next 4 columns are these same variables from the previous year. NDVI is the current year NDVI value. lagNDVI is the NDVI value from the previous year.

Donner_weather.csv: This is the summarized data from the Central Sierra Snow Lab (in Soda Springs, CA). Year refers to the calendar year (ADJUSTED FOR WATER YEAR). mean_max_temp is the mean maximum temperature in the months of Jan-Mar. mean_min_temp is the mean minimum temperature in the months of Jan-Mar. apr1_depth refers to the average snow depth during the last two weeks of March. apr1_swe refers to the average SWE in the last two weeks of March.

life_withDFF.csv: the data needed to structure the Donner model by overwintering stage. genus_species identifies the genus and species of the observed butterfly. site_name is the monitoring site. wintering identifies the stage in which that species overwinters at that site.

drought_res.csv: data that indicates how well a species did during the drought years compared to the non-drought years. genus_species identifies the genus and species of the observed butterfly. site_name is the monitoring site. z_drought is the drought response value, positive indicating that the drought years were better, negative indicating worse. species_site_name is a combination of genus_species and site_name.

making_factors.R: R script for the factor analysis

Path_analysis.R: R script for the Bayesian path analysis and creation of main results figures.

follow_up_model2.R: R script for the follow up model on Donner Pass data.
