###################################################################
###################################################################

#Code for "Thirty-six years of butterflies, snow cover, and plant productivity 
#reveal direct and indirect effects of montane climate change" pt. 3

#Author: Chris Halsch
#Date: Nov 6, 2023

#Below you will find the code relevant for running the follow up
#Donner Pass model. 

#IMPORTANT NOTE FOR RUNNING THIS CODE: 
#The model presented below needs to be run twice. Once for early flying species,
#and a second time for late flying species. Pay attention around line 62 to choose
#the subset you want. Then run the code all the way through to generate the panels 
#from figure 5.

#Line 28: Bayesian Donner model
#Line 172: Model evaluation
#Line 192: Beginning to summarize the model
#Line 269: Recreating figure 6 (effect plot)
#Line 308: Recreating figure 6 (interaction plot)

###################################################################
###################################################################

#####################################################
##########      Bayesian Donner model      ##########
#####################################################

library(bayesplot)
library(ggbeeswarm)
library(ggforce)
library(igraph)
library(loo)
library(RColorBrewer)
library(RSA)
library(rstanarm)
library(stringr)
library(tidyverse)
library(wesanderson)

setwd("~/Documents/MANUSCRIPTS/remote_meadows/data_share/final_share/")

butt_dat <- read.csv("SEM_data_share_trended.csv") #import butterfly data
life <- read.csv("life_withDFF.csv") #import life history data

#subset to Donner in the years of interest
butt_dat1 <- butt_dat %>% 
  filter(site_name == "Donner Pass") %>% 
  select(Year, genus_species, site_name, DP, visits, mdlf, dlf, NDVI) %>% 
  filter(Year >= 1985 & Year <= 2019) %>% 
  left_join(life) %>% 
  filter(wintering != "no") %>% 
  mutate(com = paste(wintering, genus_species, sep = "_"))

#import donner weather
Donner_weat <- read.csv("Donner_weather.csv")

#format donner weather
Donner_weat1 <- Donner_weat %>% 
  select(Year, mean_max_temp, mean_min_temp, apr1_swe) %>% 
  filter(Year >= 1985) %>% 
  mutate(z_mean_max_temp = scale(mean_max_temp)[,1],
         z_mean_min_temp = scale(mean_min_temp)[,1],
         z_apr1_swe = scale(apr1_swe)[,1]) %>% 
  select(Year, z_mean_max_temp, z_mean_min_temp, z_apr1_swe)

#join butterfly data with Donner weather
dat <- butt_dat1 %>%
  left_join(Donner_weat1) 

#selects predictors variables and creates interaction terms
Butt_preds <- dat %>% 
  mutate(lag_dlfr = scale(lag(dlf))[,1]) %>% 
  select(NDVI, lag_dlfr, z_mean_max_temp, z_mean_min_temp, z_apr1_swe, Year) %>%
  mutate(SWE_MAX = scale(z_mean_max_temp*(z_apr1_swe*-1))[,1],
         SWE_MIN = scale(z_mean_min_temp*(z_apr1_swe*-1))[,1],
         Year = scale(Year)[,1]) %>% 
  select(-lag_dlfr)

#set up model data
mod_data <- list(Butt = dat$DP,
                 Visits = dat$visits,
                 X1 = as.matrix(Butt_preds),
                 #X1p = as.matrix(Buttp),
                 Ncovars1 = ncol(Butt_preds),
                 wintering_index = as.numeric(factor(dat$wintering)),
                 species_index = as.numeric(factor(dat$genus_species)),
                 wintering_list = as.numeric(factor(str_split(unique(dat$com), pattern = "_", simplify = T)[,1])),
                 species_list = as.numeric(factor(str_split(unique(dat$com), pattern = "_", simplify = T)[,2])),
                 #species = as.numeric(factor(dat$genus_species)),
                 #dlf_na = which(is.na(Butt_preds$LF_SWE == T)),
                 Nwin_species = length(unique(dat$com)),
                 Nwintering = length(unique(dat$wintering)),
                 N = length(dat$Year))

sem_model <- "model {
          
          for (i in 1:N) { 
          
          #Lowest level. Here you can see the three multiple regressions, which creates the SEM framework. Each beta coefficient is nested with [species, site],
          #which results in a different estimate for each species and site combination.
          
              #Butt[i] ~ dnorm(mu1[i], sigma1)

              Butt[i] ~ dbinom(p[i], Visits[i])
              logit(p[i]) <- A1[wintering_index[i], species_index[i]] + B1[, wintering_index[i], species_index[i]] %*% X1[i,]

              LogLik1[i] <- logdensity.bin(Butt[i], p[i] , Visits[i])
              ButtP[i] ~ dbinom(p[i], Visits[i])
              
          }
          
          #Set hyper priors for butterfly model
          for (j in 1:Ncovars1) {
            for (k in 1:Nwin_species) {
            
              B1[j, wintering_list[k], species_list[k]] ~ dnorm(mbmu1[j,wintering_list[k]], mbsig1[j,wintering_list[k]])
            }
          }
          
          for (j in 1:Ncovars1) {
            for (k in 1:Nwintering) {
              mbmu1[j,k] ~ dnorm(0, 0.01)
              mbsig1[j,k] ~ dgamma(2, 0.1)
              }
            }
    
          #for (j in 1:Ncovars1) {
           # hbmu1[j] ~ dnorm(0, 0.01)
          #  hbsig1[j] ~ dgamma(2, 0.1)
          #}
          
          
          #Priors for intercept of both models
          for (k in 1:Nwin_species) {
            A1[wintering_list[k], species_list[k]] ~ dnorm(mamu1[wintering_list[k]], masig1[wintering_list[k]])
          }
          
          for (k in 1:Nwintering) {

            mamu1[k] ~ dnorm(0, 0.01)
            masig1[k] ~ dgamma(2, 0.1)
          }
          
        #hamu1 ~ dnorm(0, 0.01)
        #hasig1 ~ dgamma(2, 0.1)

}	
"

writeLines(sem_model, con="sem_model_follow.txt")

#only parameters of interest
#params <- c("A1", "B1", "hbmu1", "mbmu1", "hamu1", "ButtP", "LogLik1") #if performing model eval
params <- c("A1", "B1", "mbmu1", "ButtP", "LogLik1")

#run model
mod <- jagsUI::jags(data = mod_data,
                    n.adapt = 1000,
                    n.burnin = 1000,
                    n.iter = 20000,
                    n.chains = 4,
                    modules = "glm",
                    parallel = T,
                    model.file = "sem_model_follow.txt",
                    parameters.to.save = params,
                    verbose = TRUE)

################################################################
#### MODEL EVALUATION (uncomment "ButtP" and "LogLik1" and save those parameters)

#loo1 <- loo(mod$sims.list$LogLik1, save_psis = TRUE)
#print(loo1)

#buttp <- data.frame(mean = mod$mean$ButtP,
#                    lci = mod$q2.5$ButtP,
#                    uci = mod$q97.5$ButtP,
#                    obs = mod_data$Butt)
#cor(buttp$mean, buttp$obs)
#ggplot(data = buttp) +
#  geom_point(aes(obs, mean), pch = 21, fill = "gray50", color = "black", position = position_jitter()) +
#  geom_abline(intercept = 0, slope = 1, size = 0.5, color = "red", linetype = "dashed") +
#  labs(x = "Observed data", y = "Mean of posterior predictive distribution") +
#  theme_classic()

#ggsave("~/Documents/MANUSCRIPTS/remote_meadows/Butt(Donner)_postpred.png", width = 10, height = 8)
################################################################

################################################################
##########      Beginning to summarize the model      ##########
################################################################

summ <- data.frame(mod$summary)

################################################################
#This block joins model outputs with species names, site names,
#predictor names, and response variable names

species_key <- data.frame(species_index = as.character(1:65),
                          genus_species = levels(factor(dat$genus_species)))

wintering_key <- data.frame(wintering_index = as.character(1:4),
                       wintering_stage = levels(factor(dat$wintering)))

predictor_key1 <- data.frame(pred_index = as.character(1:ncol(Butt_preds)),
                             predictors = colnames(Butt_preds))

summ1 <- summ %>% 
  mutate(get_it = rownames(summ), get_it = substr(get_it, start = 1, stop = (nchar(get_it)-1))) %>% 
  separate(get_it, into = c("resp_index", "other"), sep = "\\[") %>%
  filter(resp_index != "p") %>% 
  filter(resp_index != "devianc") %>% 
  mutate(level = substr(resp_index, start = 1, stop = (nchar(resp_index)-1)),
         resp_index = substr(resp_index, start = (nchar(resp_index)), stop = (nchar(resp_index)))) %>% 
  separate(other, into = c("pred_index", "wintering_index", "species_index"), sep = "\\,") %>% 
  #mutate(other = substr(other, start = 1, stop = (nchar(other)-1))) %>% 
  #separate(other, into = c("pred_index", "spec_index"), sep = "\\,") %>% 
  left_join(wintering_key) %>% 
  left_join(species_key) %>% 
  left_join(predictor_key1) %>% 
  mutate(wintering_stage = ifelse(is.na(wintering_stage) == T, "overall", wintering_stage),
         genus_species = ifelse(is.na(genus_species) == T, "overall", genus_species),
         species_wintering = paste(genus_species, wintering_stage, sep = "_")) %>% 
  mutate(wintering_stage = recode(wintering_stage, adult = "Adult", egg = "Egg", larva = "Larva", pupa = "Pupa"),
         wintering_stage = as.factor(wintering_stage),
         wintering_stage = ordered(wintering_stage, levels = c("Egg", "Larva", "Pupa", "Adult"))) %>% 
  select(-resp_index, -pred_index, -species_index, -wintering_index)

#Order the factors
sep_mando1 <- summ1 %>% 
  mutate(predictors = factor(predictors, levels = c("SWE_MIN", "SWE_MAX", "z_apr1_swe", "z_mean_min_temp", "z_mean_max_temp", "NDVI", "Year"))) %>% 
  mutate(predictors = ordered(predictors, levels = c("SWE_MAX", "SWE_MIN", "z_apr1_swe", "z_mean_max_temp", "z_mean_min_temp", "NDVI", "Year"))) 

################################################################

################################################################
#Calculate across overwintering state posteriors  
adult <- data.frame(mod$sims.list$mbmu1[,,1])
colnames(adult) <- colnames(Butt_preds)
adult$wintering_stage <- "Adult"
egg <- data.frame(mod$sims.list$mbmu1[,,2])
colnames(egg) <- colnames(Butt_preds)
egg$wintering_stage <- "Egg"
larva <- data.frame(mod$sims.list$mbmu1[,,3])
colnames(larva) <- colnames(Butt_preds)
larva$wintering_stage <- "Larva"
pupa <- data.frame(mod$sims.list$mbmu1[,,4])
colnames(pupa) <- colnames(Butt_preds)
pupa$wintering_stage <- "Pupa"

summ1.1 <- rbind(adult, egg, larva, pupa)
summ1.1 <- summ1.1 %>% gather(1:7, key = "predictors", value = "mean")

sep_mando1.5 <- summ1.1 %>% 
  #filter(genus_species != "overall") %>% 
  #group_by(site_name, response, predictors) %>%
  group_by(wintering_stage, predictors) %>%
  summarise(mn = mean(mean, na.rm = T),
            lci = quantile(mean, 0.1, na.rm = T),
            uci = quantile(mean, 0.9,  na.rm = T)) %>% 
  mutate(predictors = factor(predictors, levels = c("SWE_MIN", "SWE_MAX", "z_apr1_swe", "z_mean_min_temp", "z_mean_max_temp", "NDVI", "Year"))) %>%
  mutate(predictors = ordered(predictors, levels = c("SWE_MAX", "SWE_MIN", "z_apr1_swe", "z_mean_max_temp", "z_mean_min_temp", "NDVI", "Year"))) %>% 
  mutate(wintering_stage = ordered(wintering_stage, levels = c("Egg", "Larva", "Pupa", "Adult")))
################################################################

################################################################
########      Recreating figure 6 (effect plot)      ###########
################################################################

plot_sep1 <- ggplot() +
  geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf), fill = "gray95") + 
  geom_vline(aes(xintercept = 0), color = "black", linetype = "dashed") +
  geom_hline(aes(yintercept = 1.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 2.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 3.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 4.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 5.5), color = "black", linetype = "dotted") +
  geom_hline(aes(yintercept = 6.5), color = "black", linetype = "dotted") +
  geom_quasirandom(data = subset(sep_mando1, level == "B" & f < 0.8), aes(mean, y=predictors, fill = wintering_stage), pch = 21, method = "quasirandom", alpha = 0.25, size = 3, dodge.width = -0.75, show.legend = F) + #position = position_jitterdodge(dodge.width = 0.75, jitter.width = 0.15)) +
  geom_quasirandom(data = subset(sep_mando1, level == "B" & f >= 0.8), aes(mean, y=predictors, fill = wintering_stage), pch = 21,  method = "quasirandom", alpha = 0.75, size = 3,  dodge.width = -0.75, show.legend = F) + #position = position_jitterdodge(dodge.width = 0.75, jitter.width = 0.15)) +
  geom_errorbarh(data = subset(sep_mando1.5), aes(xmin = lci, xmax = uci, y = predictors, group = wintering_stage), color = "black", size = 1.5, height = 0, position = position_dodge(width = -0.75), show.legend = F) +
  geom_errorbarh(data = subset(sep_mando1.5), aes(xmin = lci, xmax = uci, y = predictors, color = wintering_stage), size = 0.75, height = 0, position = position_dodge(width = -0.75), show.legend = F) +
  geom_point(data = subset(sep_mando1.5), aes(mn, predictors, fill = wintering_stage), color = "black", size = 5, pch = 21, position = position_dodge(width = -0.75)) +
  #geom_errorbarh(data = subset(sep_mando1.5, response == "Butt"), aes(xmin = lci, xmax = uci, y = predictors), color = "black", size = 0.75, height = 0) +
  #geom_point(data = subset(sep_mando1.5, response == "Butt"), aes(mn, predictors), fill = "black", color = "black", size = 4, pch = 21) +
  scale_fill_manual(values = wes_palette("IsleofDogs1")[c(2,3,5,1)]) +
  scale_color_manual(values = wes_palette("IsleofDogs1")[c(2,3,5,1)]) +
  #coord_cartesian(xlim = c(-0.5, 0.5)) +
  labs(x = "Effect size", fill = "Site", y = "Predictors") +
  scale_y_discrete(labels = c("Apr. 1 snow*\nMax. temp", "Apr. 1 snow*\nMin. temp", "Apr. 1 snow", "Max. temp.", "Min. temp.", "Productivity", "Year")) +
  theme_classic() +
  theme(legend.position = "bottom",
        legend.background = element_blank(),
        axis.title.y = element_blank(),
        axis.title.x = element_text(size = 20, face = "bold"),
        axis.text = element_text(size = 18),
        legend.text = element_text(size = 18),
        legend.title = element_text(face = "bold", size = 18),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        axis.line = element_blank(),
        plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm"))
plot_sep1
#ggsave("~/Documents/MANUSCRIPTS/remote_meadows/donner_coef.png", width = 6, height = 10)

#####################################################################
########      Recreating figure 6 (interaction plot)      ###########
#####################################################################

#look at only eggs and larvae
alpha_e <- summ1 %>% 
  filter(level == "B" | level == "A") %>% 
  filter(wintering_stage == "Egg" | wintering_stage == "Larva" | is.na(wintering_stage) == T) %>% 
  mutate(predictors = ifelse(level == "A", "alpha", predictors)) %>% 
  group_by(predictors) %>% 
  summarise(mean_e = mean(mean))

#extract effect sizes from model
alpha <- alpha_e$mean_e[5]
effect_NDVI <- alpha_e$mean_e[1]
effect_z_mean_max_temp <- alpha_e$mean_e[7]
effect_z_mean_min_temp <- alpha_e$mean_e[8]
effect_z_apr1_swe <- alpha_e$mean_e[6]
effect_year_ <- alpha_e$mean_e[4]
effect_lag_SWEMAX <- alpha_e$mean_e[2]
effect_lag_SWEMIN <- alpha_e$mean_e[3]

#save color palette
pal <- colorRampPalette(c(wes_palette("Chevalier1")[2], "white",wes_palette("Chevalier1")[1]))(12)

#make figure
png("max_temp_inter_def.png", width = 1000, height = 1000, bg = "transparent")
#png("min_temp_inter_def.png", width = 1000, height = 1000, bg = "transparent")
#par(bg=NA)
zlim <- c(-3.25, alpha + 1.9)
ylim <- c(-3,3)
xlim <- c(-3,3)
plotRSA(x = effect_z_apr1_swe, y = effect_z_mean_max_temp,
        xy = effect_lag_SWEMAX, b0 = alpha, 
        pal = pal, pal.range = "surface", rotation = list(x = -75, y = 70, z = 14), param = F,
        label.rotation = list(x = 95, y = 5, z = 89), gridsize = 50, link = "identity", 
        axes = c("PA1", "PA2"), tck = c(1, 1, 1), distance = c(1, 1, 1.5), cex.tickLabel = 1, pad = -30, zlim = zlim, xlim = xlim, ylim = ylim,
        contour = list(show = FALSE, color = NA, highlight = c()), legend = F, cex.axesLabel = 0)

dev.off()

################################################################

