###################################################################
###################################################################

#Code for "Thirty-six years of butterfly monitoring, snow cover, 
#and plant productivity reveal negative impacts of warmer winters 
#and increased productivity on montane species" pt. 1

#Author: Chris Halsch
#Date: Nov 6, 2023

#Below you will find the code relevant for performing the factor analysis 
#and generating the factors used as predictor variables in the path analysis

###################################################################
###################################################################

library(data.table)
library(nFactors)
library(tidyverse)

setwd("~/Documents/MANUSCRIPTS/remote_meadows/data_share/final_share/")

#Import climate data
clim <- read.csv("climate.csv")

#Assign months with season
seasons <- data.frame(Month = 1:12,
                      Season = c("Win", "Win", "Win", 
                                 "Spr", "Spr", "Spr", 
                                 "Sum", "Sum", "Sum", 
                                 "Fal", "Fal", "Fal"))
clim <- left_join(clim, seasons, by = "Month")

#Adjust to water year, making Fall from the previous year impact butterflies
water_year1 <- clim %>% filter(Season != "Fal")
water_year2 <- clim %>% filter(Season == "Fal") %>% mutate(Year = Year + 1)
clim <- rbind(water_year1, water_year2)

#subset to only the relevant variables
clim1 <- clim %>% 
  gather(4:7, key = "Var", value = "val") %>% 
  mutate(var = paste(Var, Season, sep = "_")) %>% 
  group_by(meadow_name, Year, var) %>% 
  summarise(val = mean(val)) %>% 
  filter(var != "pck_Spr" & var != "pck_Sum") %>% 
  spread(key = "var", value = "val") %>% 
  filter(Year >= 1960 & Year < 2021) %>% 
  filter(meadow_name != "Castle_big") %>% 
  na.omit()

#This for loop scales and detrends all climate variables within site
clim_sites <- unique(clim1$meadow_name)
datlist1 <- list()
for (i in 1:length(clim_sites)) {
  temp <- clim1 %>% filter(meadow_name == clim_sites[i])
  
  for (j in 3:ncol(temp)) {
    temp1 <- data.frame(cbind(temp[,2], temp[,j]))
    mod <- glm(temp1[,2] ~ temp1[,1])
    new_col <- scale(resid(mod))[,1]
    temp[,j] <- new_col
  }
  #temp1 <- data.frame(apply(temp[,3:16], 2, scale))
  datlist1[[i]] <- temp
}

out <- rbindlist(datlist1)

#This block performs an exploratory analysis of weather covariation
ev <- eigen(cor(out[,3:16])) # get eigenvalues
ap <- parallel(subject=nrow(out[,3:16]),var=ncol(out[,3:16]),
               rep=100,cent=.05)
nS <- nScree(x=ev$values, aparallel=ap$eigen$qevpea)
plotnScree(nS) #4 factors seems best

#performs factor analysis
fit <- psych::fa(r = out[,3:16], nfactors = 4, rotate = "oblimin")
fit

#Factor 1: Early winter (10-12) precip/snow (higher = more precip)
#Factor 2: Early growing season (4-6) conditions (higher = hotter/drier)
#Factor 3: Late winter (1-3) (higher = hotter)
#Factor 4: Late growing season (7-9) conditions (higher = hotter/drier)

#save loadings
#write.csv(fit$weights, "~/Documents/MANUSCRIPTS/remote_meadows/load.csv", row.names = F)

#generate scores for each year, note that I use the non-detrended data here.
predictions <- predict(fit, clim1[,3:16])
pred1 <- data.frame(meadow_name = clim1$meadow_name,
                    Year = clim1$Year)
pred1 <- data.frame(cbind(pred1, predictions))
pred1 <- pred1 %>% filter(Year >= 1982)

#scales factors and generates lagged variables
sites <- unique(pred1$meadow_name)
datlist <- list()
for (i in 1:length(sites)) {
  temp <- pred1 %>% filter(meadow_name == sites[i])
  temp1 <- data.frame(cbind(temp[,1:2], scale(temp[,3:ncol(temp)])))
  temp1$lagMR1 <- lag(temp1$MR1)
  temp1$lagMR2 <- lag(temp1$MR2)
  temp1$lagMR3 <- lag(temp1$MR3)
  temp1$lagMR4 <- lag(temp1$MR4)
  datlist[[i]] <- temp1
}

pred1 <- data.table::rbindlist(datlist)

pred1$meadow_name <- recode(pred1$meadow_name, 
                              Castle_small = "Castle Peak",
                              Donner = "Donner Pass",
                              Lang = "Lang Crossing")

#write.csv(pred1, "~/Documents/MANUSCRIPTS/remote_meadows/data/factors_trended.csv", row.names = F)





